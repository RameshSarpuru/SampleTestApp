﻿using System;
using SQLite;


namespace SampleTestApp
{
    public interface ISQLite
    {
        SQLiteConnection GetConnection();
    }
}
