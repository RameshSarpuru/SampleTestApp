﻿using System;
using System.Collections.Generic;
using SampleTestApp.Pages;
using Xamarin.Forms;

namespace SampleTestApp
{
    public partial class Page1 : ContentPage
    {
        public Page1(ListViewTemplate listView)
        {
            InitializeComponent();
            mainLbl.Text = listView.Name;
            subLbl.Text = listView.Designation;
        }
    }
}
