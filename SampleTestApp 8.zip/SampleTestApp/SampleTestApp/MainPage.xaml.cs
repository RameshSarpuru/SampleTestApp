﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SampleTestApp.Pages;
using Xamarin.Forms;

namespace SampleTestApp
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        List<ListViewTemplate> newList;
        public MainPage()
        {
            InitializeComponent();
            newList = new List<ListViewTemplate>();
            MainListView.ItemsSource = new List<ListViewTemplate>
            

            {
            new ListViewTemplate
                {
                Name = "Xamarin.Forms",
                    Designation = "One",
                    Department = 1
               },
               new ListViewTemplate
               {
                   Name = "Android",
                   Designation = "Two",
                   Department = 2
                },
                new ListViewTemplate
                {
                    Name = "IOS",
                    Designation = "Three",
                    Department = 3
               },
               new ListViewTemplate
               {
                   Name = "Windows",
                   Designation = "Four",
                   Department = 4
               }
               
           };
           // newList.Add(ListViewTemplate as List);
        }
        async private void MainListView_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            var Selected = e.Item as ListViewTemplate;

            switch (Selected.Department)
            {
                case 1:
                    await Navigation.PushAsync(new Page1(Selected));
                    break;
                case 2:
                    await Navigation.PushAsync(new Page1(Selected));
                    break;
                case 3:
                    await Navigation.PushAsync(new Page1(Selected));
                    break;
                case 4:
                    await Navigation.PushAsync(new Page1(Selected));
                    break;
            }

            ((ListView)sender).SelectedItem = null;


        }
        public void DeleteClicked(object sender, EventArgs e)
        {
            var item = (Xamarin.Forms.Button)sender;
            ListViewTemplate listitem = (from itm in newList
                                         where itm.Name == item.CommandParameter.ToString()
                             select itm)
                            .FirstOrDefault<ListViewTemplate>();
            newList.Remove(listitem);
        }
    }
}
