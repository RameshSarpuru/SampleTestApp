﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace SampleTestApp.Pages
{
    public partial class ListViewTemplate : ContentPage
    {
        public string Name { get; set; }
        public string Designation { get; set; }

        public int Department { get; set; }

        public ListViewTemplate()
        {
            InitializeComponent();
        }
    }
}
