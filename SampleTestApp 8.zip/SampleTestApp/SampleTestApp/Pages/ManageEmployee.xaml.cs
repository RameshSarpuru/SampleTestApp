﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace SampleTestApp.Pages
{
    public partial class ManageEmployee : ContentPage
    {
         List<ListViewTemplate> newList;
        Employee aSelectedEmp;
        public ManageEmployee()
        {
            InitializeComponent();
            var vList = App.DAUtil.GetAllEmployees();
            lstData.ItemsSource = vList;

            // lstData.ItemsSource = new List<ListViewTemplate>


            // {
            // new ListViewTemplate
            //     {
            //     Name = "Xamarin.Forms",
            //         Designation = "One",
            //         Department = 1
            //    },
            //    new ListViewTemplate
            //    {
            //        Name = "Android",
            //        Designation = "Two",
            //        Department = 2
            //     },
            //     new ListViewTemplateOnNewClicked
            //     {
            //         Name = "IOS",
            //         Designation = "Three",
            //         Department = 3
            //    },
            //    new ListViewTemplate
            //    {
            //        Name = "Windows",
            //        Designation = "Four",
            //        Department = 4
            //    }

            //};
        }
        public void editBtnClicked(object sender, EventArgs e)
        {
            Employee mSelEmployee = ((MenuItem)sender).CommandParameter as Employee;
            //  Employee aSelectedEmp = ((MenuItem)sender).CommandParameter as Employee;
            Navigation.PushAsync(new EditEmployee(mSelEmployee));
            
        }
        public async void deleteBtnClicked(object sender, EventArgs e)
        {
            Employee mSelEmployee = ((MenuItem)sender).CommandParameter as Employee;
            bool accepted = await DisplayAlert("Confirm", "Are you Sure ?", "Yes", "No");
            if (accepted)
            {
                App.DAUtil.DeleteEmployee(mSelEmployee);
            }
            var vList = App.DAUtil.GetAllEmployees();
            lstData.ItemsSource = vList;

            // await Navigation.PushAsync(new ManageEmployee());
        }

        void OnSelection(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null)
            {
                return;
                //ItemSelected is called on deselection,   
                //which results in SelectedItem being set to null  
            }
            var vSelUser = (Employee)e.SelectedItem;
            Navigation.PushAsync(new ShowEmplyee(vSelUser));
        }
        public void OnNewClicked(object sender, EventArgs args)
        {
            Navigation.PushAsync(new AddEmployee());
        }
    }
}
